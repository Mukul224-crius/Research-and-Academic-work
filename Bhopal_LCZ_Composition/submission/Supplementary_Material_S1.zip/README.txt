Supplementary Material S1
Inputs: QGIS "Raster layer unique values report" frequency tables for the LCZ raster (95.1595 m, EPSG:32643)
and the 10 m LULC 2017 raster, plus the LCZ raster's size/extent metadata.
Run:  python3 scripts/compute_statistics.py && python3 scripts/compute_lulc_statistics.py   (requires numpy)
Outputs (validation/*.json, *.txt) contain every statistic reported in the article.
